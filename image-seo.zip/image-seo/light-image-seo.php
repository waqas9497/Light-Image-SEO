<?php
/*
Plugin Name: Light Image SEO
Plugin URI: https://iamwaqas.com
Description: Automatically add smart SEO-friendly alt tags and descriptions to your images using image name, post title, and meta description.
Version: 1.0.0
Author: Waqas Ahmed
Author URI: https://iamwaqas.com
License: GPL2
*/

// Prevent direct access to this file
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('LIGHT_IMAGE_SEO_VERSION', '1.0.0');
define('LIGHT_IMAGE_SEO_PATH', plugin_dir_path(__FILE__));
define('LIGHT_IMAGE_SEO_URL', plugin_dir_url(__FILE__));

class Light_Image_SEO {
    private static $instance = null;
    private $default_settings = array(
        'auto_alt_tags' => 1
    );

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Initialize plugin
        add_action('init', array($this, 'init'));
        
        // Admin hooks
        if (is_admin()) {
            add_action('admin_menu', array($this, 'add_admin_menu'));
            add_action('admin_init', array($this, 'register_settings'));
            add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
            
            // Modify plugin meta links
            add_filter('plugin_row_meta', array($this, 'plugin_row_meta'), 10, 2);
        }

        // Get plugin options with defaults
        $options = wp_parse_args(get_option('light_image_seo_options', array()), $this->default_settings);

        // Image processing hooks - only add if auto_alt_tags is enabled
        if ($options['auto_alt_tags']) {
            add_filter('wp_handle_upload_prefilter', array($this, 'pre_upload'));
            add_filter('wp_handle_upload', array($this, 'post_upload'));
            add_action('add_attachment', array($this, 'process_new_image'));
            add_filter('wp_insert_post_data', array($this, 'process_post_images'), 10, 2);
            add_action('save_post', array($this, 'process_saved_post'), 10, 3);
        }
    }

    public function init() {
        // Load text domain for internationalization
        load_plugin_textdomain('light-image-seo', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function add_admin_menu() {
        add_options_page(
            __('Light Image SEO Settings', 'light-image-seo'),
            __('Light Image SEO', 'light-image-seo'),
            'manage_options',
            'light-image-seo',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting(
            'light_image_seo_settings',
            'light_image_seo_options',
            array(
                'type' => 'array',
                'sanitize_callback' => array($this, 'sanitize_settings'),
                'default' => $this->default_settings
            )
        );

        add_settings_section(
            'light_image_seo_main',
            __('Main Settings', 'light-image-seo'),
            array($this, 'settings_section_callback'),
            'light-image-seo'
        );

        add_settings_field(
            'auto_alt_tags',
            __('Auto Generate Alt Tags', 'light-image-seo'),
            array($this, 'auto_alt_tags_callback'),
            'light-image-seo',
            'light_image_seo_main'
        );
    }

    public function sanitize_settings($input) {
        $sanitized = array();
        
        // Ensure we have an array
        if (!is_array($input)) {
            $input = array();
        }
        
        // Sanitize auto_alt_tags
        $sanitized['auto_alt_tags'] = isset($input['auto_alt_tags']) ? 1 : 0;
        
        return $sanitized;
    }

    public function settings_section_callback() {
        echo '<p>' . __('Configure how Light Image SEO handles your image attributes.', 'light-image-seo') . '</p>';
    }

    public function auto_alt_tags_callback() {
        $options = wp_parse_args(get_option('light_image_seo_options', array()), $this->default_settings);
        ?>
        <label>
            <input type='checkbox' name='light_image_seo_options[auto_alt_tags]' 
                   <?php checked($options['auto_alt_tags'], 1); ?> value='1'>
            <?php _e('Automatically generate alt tags for new uploads', 'light-image-seo'); ?>
        </label>
        <?php
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        // Process bulk operation if requested
        if (isset($_POST['bulk_process_images']) && check_admin_referer('light_image_seo_bulk_process')) {
            $this->bulk_process_images();
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <?php settings_errors('light_image_seo_messages'); ?>
            
            <form action='options.php' method='post'>
                <?php
                settings_fields('light_image_seo_settings');
                do_settings_sections('light-image-seo');
                submit_button();
                ?>
            </form>

            <hr>

            <h2><?php _e('Bulk Process Images', 'light-image-seo'); ?></h2>
            <form method="post" action="">
                <?php wp_nonce_field('light_image_seo_bulk_process'); ?>
                <p>
                    <?php _e('Click the button below to process all existing images in your media library.', 'light-image-seo'); ?>
                </p>
                <input type="submit" name="bulk_process_images" class="button button-primary" 
                       value="<?php _e('Process All Images', 'light-image-seo'); ?>">
            </form>

            <hr>

            <div class="light-image-seo-info">
                <p>
                    <?php 
                    printf(
                        __('Version: %s | Developed by %s', 'light-image-seo'),
                        LIGHT_IMAGE_SEO_VERSION,
                        '<a href="https://iamwaqas.com" target="_blank">Waqas Ahmed</a>'
                    );
                    ?>
                </p>
            </div>
        </div>
        <?php
    }

    public function enqueue_admin_scripts($hook) {
        if ('settings_page_light-image-seo' !== $hook) {
            return;
        }
        wp_enqueue_style('light-image-seo-admin', LIGHT_IMAGE_SEO_URL . 'admin/css/admin.css', array(), LIGHT_IMAGE_SEO_VERSION);
    }

    private function generate_seo_text($image_id, $post_id = null) {
        // Get the image filename without extension
        $filename = pathinfo(get_post_meta($image_id, '_wp_attached_file', true), PATHINFO_FILENAME);
        $filename = str_replace(array('-', '_'), ' ', $filename);
        $filename = ucwords($filename);

        $alt_parts = array($filename);

        if ($post_id) {
            // Add post title
            $post_title = get_the_title($post_id);
            if ($post_title) {
                $alt_parts[] = $post_title;
            }

            // Try to get meta description from Yoast SEO
            $yoast_meta = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
            if ($yoast_meta) {
                $alt_parts[] = $yoast_meta;
            } else {
                // Try AIOSEO description
                $aioseo_meta = get_post_meta($post_id, '_aioseo_description', true);
                if ($aioseo_meta) {
                    $alt_parts[] = $aioseo_meta;
                } else {
                    // Fallback to post excerpt
                    $post = get_post($post_id);
                    if ($post && $post->post_excerpt) {
                        $alt_parts[] = $post->post_excerpt;
                    }
                }
            }
        }

        // Combine parts and clean up
        $seo_text = implode(' - ', array_filter($alt_parts));
        $seo_text = wp_strip_all_tags($seo_text);
        $seo_text = sanitize_text_field($seo_text);
        
        // Limit length to reasonable SEO-friendly size
        return substr($seo_text, 0, 125);
    }

    public function process_new_image($attachment_id) {
        $options = wp_parse_args(get_option('light_image_seo_options', array()), $this->default_settings);
        
        if (!$options['auto_alt_tags']) {
            return;
        }

        // Check if it's an image
        if (!wp_attachment_is_image($attachment_id)) {
            return;
        }

        // Get parent post ID if exists
        $parent_id = wp_get_post_parent_id($attachment_id);
        
        // Generate SEO text
        $seo_text = $this->generate_seo_text($attachment_id, $parent_id);
        
        if (!empty($seo_text)) {
            // Update alt text if it doesn't exist
            $current_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
            if (empty($current_alt)) {
                update_post_meta($attachment_id, '_wp_attachment_image_alt', $seo_text);
            }
            
            // Update only the description
            wp_update_post(array(
                'ID' => $attachment_id,
                'post_content' => $seo_text, // Description only
            ));
        }
    }

    public function process_post_images($data, $postarr) {
        if (!isset($postarr['ID'])) {
            return $data;
        }

        $options = wp_parse_args(get_option('light_image_seo_options', array()), $this->default_settings);
        if (!$options['auto_alt_tags']) {
            return $data;
        }

        // Process content for image tags without alt
        if (isset($data['post_content'])) {
            $content = $data['post_content'];
            
            // Use DOMDocument to properly parse HTML
            if (!empty($content)) {
                $dom = new DOMDocument();
                libxml_use_internal_errors(true);
                $dom->loadHTML(mb_convert_encoding($content, 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
                libxml_clear_errors();

                $images = $dom->getElementsByTagName('img');
                $modified = false;

                foreach ($images as $img) {
                    $needs_update = false;
                    
                    // Check for alt attribute
                    if (!$img->hasAttribute('alt') || empty($img->getAttribute('alt'))) {
                        $needs_update = true;
                    }
                    
                    if ($needs_update) {
                        // Try to get attachment ID from class
                        $classes = $img->getAttribute('class');
                        preg_match('/wp-image-(\d+)/', $classes, $matches);
                        
                        if (isset($matches[1])) {
                            $attachment_id = $matches[1];
                            $seo_text = $this->generate_seo_text($attachment_id, $postarr['ID']);
                            
                            if (!empty($seo_text)) {
                                if (!$img->hasAttribute('alt') || empty($img->getAttribute('alt'))) {
                                    $img->setAttribute('alt', $seo_text);
                                }
                                $modified = true;
                            }
                        }
                    }
                }

                if ($modified) {
                    $data['post_content'] = $dom->saveHTML();
                }
            }
        }

        return $data;
    }

    public function process_saved_post($post_id, $post, $update) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        $options = wp_parse_args(get_option('light_image_seo_options', array()), $this->default_settings);
        if (!$options['auto_alt_tags']) {
            return;
        }

        // Process featured image
        if (has_post_thumbnail($post_id)) {
            $thumbnail_id = get_post_thumbnail_id($post_id);
            $needs_update = false;
            
            // Check alt text
            $current_alt = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
            if (empty($current_alt)) {
                $needs_update = true;
            }
            
            if ($needs_update) {
                $seo_text = $this->generate_seo_text($thumbnail_id, $post_id);
                if (!empty($seo_text)) {
                    update_post_meta($thumbnail_id, '_wp_attachment_image_alt', $seo_text);
                    
                    // Update title/description if enabled
                    if ($options['add_title_attr']) {
                        wp_update_post(array(
                            'ID' => $thumbnail_id,
                            'post_excerpt' => $seo_text, // Caption
                            'post_content' => $seo_text, // Description
                        ));
                    }
                }
            }
        }
    }

    public function bulk_process_images() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $args = array(
            'post_type' => 'attachment',
            'post_mime_type' => array('image/jpeg', 'image/png', 'image/gif'),
            'post_status' => 'inherit',
            'posts_per_page' => -1,
        );

        $images = get_posts($args);
        $processed = 0;
        $updated_alt = 0;
        $updated_desc = 0;
        $options = wp_parse_args(get_option('light_image_seo_options', array()), $this->default_settings);

        foreach ($images as $image) {
            $current_alt = get_post_meta($image->ID, '_wp_attachment_image_alt', true);
            $parent_id = wp_get_post_parent_id($image->ID);
            $seo_text = $this->generate_seo_text($image->ID, $parent_id);
            
            if (!empty($seo_text)) {
                $was_updated = false;
                
                // Update alt text if empty
                if (empty($current_alt)) {
                    update_post_meta($image->ID, '_wp_attachment_image_alt', $seo_text);
                    $updated_alt++;
                    $was_updated = true;
                }
                
                // Update description only
                if (empty($image->post_content)) {
                    wp_update_post(array(
                        'ID' => $image->ID,
                        'post_content' => $seo_text, // Description only
                    ));
                    $updated_desc++;
                    $was_updated = true;
                }
                
                if ($was_updated) {
                    $processed++;
                }
            }
        }

        // Add detailed success message
        $message = sprintf(
            __('Bulk processing complete: %1$d images processed (%2$d alt tags, %3$d descriptions updated).', 'light-image-seo'),
            $processed,
            $updated_alt,
            $updated_desc
        );
        
        add_settings_error(
            'light_image_seo_messages',
            'light_image_seo_bulk_success',
            $message,
            'updated'
        );
    }

    public function pre_upload($file) {
        // Verify it's an image
        if (!preg_match('/(jpg|jpeg|png|gif)$/i', $file['name'])) {
            return $file;
        }
        return $file;
    }

    public function post_upload($file) {
        return $file;
    }

    /**
     * Modify plugin row meta
     */
    public function plugin_row_meta($links, $file) {
        if (plugin_basename(__FILE__) === $file) {
            // Define the new author link
            $author_link = array(
                'author_link' => '<a href="' . esc_url('https://iamwaqas.com') . '" target="_blank">' . __('Visit plugin site', 'light-image-seo') . '</a>'
            );
            
            // Remove the View details link if it exists
            foreach ($links as $key => $link) {
                if (strpos($link, 'View details') !== false) {
                    unset($links[$key]);
                }
            }
            
            // Merge the remaining links with our new author link
            $links = array_merge($links, $author_link);
        }
        return $links;
    }
}

// Initialize the plugin
function light_image_seo_init() {
    Light_Image_SEO::get_instance();
}
add_action('plugins_loaded', 'light_image_seo_init');

// Activation hook
register_activation_hook(__FILE__, 'light_image_seo_activate');
function light_image_seo_activate() {
    // Add default options
    $default_settings = array(
        'auto_alt_tags' => 1
    );
    add_option('light_image_seo_options', $default_settings);
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'light_image_seo_deactivate');
function light_image_seo_deactivate() {
    // Cleanup if needed
} 